<!-- #Header_bg -->
<div id="Header_wrapper" >

<!-- #Header -->
<header id="Header">
    
<div id="Action_bar">
<div class="container">
<div class="column one">

    <ul class="contact_details">
        <li class="slogan"> GLOBAL COMMUNITY FOR WOMEN</li><li class="phone"><i class="icon-phone"></i><a href="tel:(+91)-9315854688">(+91)- 9315854688</a></li><li class="mail"><i class="icon-mail-line"></i><a href="mailto:president@womennovator.co.in">president@womennovator.co.in</a></li>				</ul>
    
    <ul class="social"><li class="facebook"><a target="_blank" href="https://www.facebook.com/womennovator/" title="Facebook"><i class="icon-facebook"></i></a></li><li class="twitter"><a target="_blank" href="https://twitter.com/womennovator" title="Twitter"><i class="icon-twitter"></i></a></li><li class="youtube"><a target="_blank" href="https://www.youtube.com/channel/UCY7ojnIQ727UzC6cSnO7PIA" title="YouTube"><i class="icon-play"></i></a></li><li class="linkedin"><a target="_blank" href="https://www.linkedin.com/company/womenovator/" title="LinkedIn"><i class="icon-linkedin"></i></a></li><li class="instagram"><a target="_blank" href="https://www.instagram.com/womennovator/" title="Instagram"><i class="icon-instagram"></i></a></li></ul>
</div>
</div>
</div>


<!-- .header_placeholder 4sticky  -->
<div class="header_placeholder"></div>

<div id="Top_bar" class="loading">

<div class="container">
<div class="column one">

<div class="top_bar_left clearfix">

    <!-- Logo -->
    <div class="logo"><h1><a id="logo" href="https://www.womennovator.co.in" title="Womennovator" data-height="85" data-padding="8"><img class="logo-main scale-with-grid" src="{{ url('frontEnd/images/WELogo.png')}}" data-retina="" data-height="720" alt="WomennovatorTM (1)" /><img class="logo-sticky scale-with-grid" src="{{ url('frontEnd/images/WELogo.png')}}" data-retina="" data-height="720" alt="WomennovatorTM (1)" /><img class="logo-mobile scale-with-grid" src="{{ url('frontEnd/images/WELogo.png')}}" data-retina="" data-height="720" alt="WomennovatorTM (1)" /><img class="logo-mobile-sticky scale-with-grid" src="{{ url('frontEnd/images/WELogo.png')}}" data-retina="" data-height="720" alt="WomennovatorTM (1)" /></a></h1></div>			
    <div class="menu_wrapper">
        <nav id="menu">
            <ul id="menu-menu" class="menu menu-main">
                <li id="menu-item-302" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="https://www.womennovator.co.in/about/"><span>ABOUT</span></a>
<ul class="sub-menu">
<li id="menu-item-2575" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/media-2/"><span>MEDIA</span></a></li>
</ul>
</li>
<li id="menu-item-618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="{{ url('http://wedistributors.womennovators.com/')}}"><span>WEMARK</span></a>

<li id="menu-item-618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="{{ url('http://lms.womennovators.com/')}}"><span>LEARNING</span></a>
<!-- <li id="menu-item-618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="{{ url('https://www.womennovators.com/reseller')}}"><span>RESELLER</span></a>
<!-- <ul class="sub-menu">
<li id="menu-item-5208" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/we-incubation/"><span>Womennvator WE Incubation</span></a></li>
<li id="menu-item-5014" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/we-exhibition/"><span>WE Exhibition</span></a></li>
<li id="menu-item-4801" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/womenmark-2/"><span>WE &#8211; Womenmark</span></a></li>
<li id="menu-item-4802" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/brand-equity/"><span>WE &#8211; Brand Ambassador</span></a></li>
<li id="menu-item-4803" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/management-planner/"><span>WE &#8211; Management Planner</span></a></li>
<li id="menu-item-286" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-cell/"><span>WE-Cell</span></a></li>
<li id="menu-item-4804" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/we-fund/"><span>WE &#8211; Fund</span></a></li>
<li id="menu-item-274" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-talks/"><span>WE-Talks</span></a></li>
<li id="menu-item-5340" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/mentors/"><span>WE Mentors</span></a></li>
<li id="menu-item-277" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-vendor-meet/"><span>WE-Vendor Meet</span></a></li>
<li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-embassy-meet/"><span>WE-Embassy Meet</span></a></li>
<li id="menu-item-291" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-pitch-to-fund/"><span>WE-Pitch To Fund</span></a></li>
<li id="menu-item-1524" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/w-global-tours/"><span>WE–Global Tours</span></a></li>
</ul> -->
</li>
<li id="menu-item-684" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="{{ url('https://www.womennovators.com/womennovator-live-series')}}"><span>LIVE-SERIES</span></a>
<!-- <ul class="sub-menu">
<li id="menu-item-680" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="https://www.womennovator.co.in/apply-for-influencer/"><span>Influencer</span></a>
<ul class="sub-menu">
<li id="menu-item-466" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/influencer-2021/"><span>INFLUENCER 2021</span></a></li>
<li id="menu-item-464" class="menu-item menu-item-type-post_type menu-item-object-page"><a target="_blank" href="https://www.womennovator.co.in/influencer-2018/"><span>INFLUENCER 2018</span></a></li>
</ul>
</li>
<li id="menu-item-230" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="https://www.womennovator.co.in/knowing-you-better-jurywi2019/"><span>Jury Members</span></a>
<ul class="sub-menu">
<li id="menu-item-2106" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/jury-members-2019/"><span>JURY MEMBERS 2021</span></a></li>
<li id="menu-item-328" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/jury-members-2018/"><span>JURY MEMBERS 2018</span></a></li>
</ul>
</li>
<li id="menu-item-4753" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a><span>women faces</span></a>
<ul class="sub-menu">
<li id="menu-item-4754" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/winners/"><span>Women faces 2021</span></a></li>
<li id="menu-item-2094" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/100-women-faces-2018/"><span>Women faces 2018</span></a></li>
</ul>
</li>
<li id="menu-item-5506" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/join-our-community/"><span>Community Head</span></a></li>
<li id="menu-item-236" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/value-partner/"><span>Value Partner</span></a></li>
<li id="menu-item-239" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/academic-partner/"><span>Academic Partner</span></a></li>
<li id="menu-item-242" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/association-partner/"><span>Association Partner</span></a></li>
<li id="menu-item-2242" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="https://womennovator.co.in/"><span>Committee</span></a>
<ul class="sub-menu">
<li id="menu-item-2243" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/management-committee-2/"><span>Management Committee</span></a></li>
<li id="menu-item-2244" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/executive-committee/"><span>Executive Committee</span></a></li>
<li id="menu-item-2246" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/mentor-2018/"><span>MENTORS</span></a></li>
</ul>
</li>
</ul> -->
</li>
<li id="menu-item-415" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="{{ url('certificateform')}}"><span>CERTIFICATE</span></a>
<ul class="sub-menu">
<li id="menu-item-686" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/upcoming-events/"><span>Upcoming Events</span></a></li>
<li id="menu-item-2093" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/past-events/"><span>Past Events</span></a></li>
<li id="menu-item-4428" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/speaker/"><span>SPEAKER</span></a></li>
</ul>
</li>
<!-- <li id="menu-item-416" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a><span>CATEGORY</span></a>
<ul class="sub-menu">
<li id="menu-item-851" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/sectors/"><span>Sectors</span></a></li>
<li id="menu-item-2304" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.womennovator.co.in/india/"><span>City</span></a></li>
</ul>
</li>
<li id="menu-item-2722" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a><span>WORK WITH US</span></a>
<ul class="sub-menu">
<li id="menu-item-2608" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.womennovator.co.in/internship/"><span>INTERNSHIP</span></a></li>
<li id="menu-item-2721" class="menu-item menu-item-type-post_type menu-item-object-page"><a target="_blank" href="https://www.womennovator.co.in/career-2/"><span>CAREER</span></a></li>
</ul>
</li>-->
<li id="menu-item-5522" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://covidcaregiver.org/"><span>CovidCare</span></a></li>
</ul><ul id="menu-menu-1" class="menu menu-mobile"><li id="menu-item-302" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-302"><a href="https://www.womennovator.co.in/about/"><span>ABOUT</span></a>
<ul class="sub-menu">
<li id="menu-item-2575" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2575"><a href="https://www.womennovator.co.in/media-2/"><span>MEDIA</span></a></li>
</ul>
</li>
<li id="menu-item-618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-618"><a><span>PROGRAMS</span></a>
<ul class="sub-menu">
<li id="menu-item-5208" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5208"><a href="https://www.womennovator.co.in/we-incubation/"><span>Womennvator WE Incubation</span></a></li>
<li id="menu-item-5014" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5014"><a href="https://www.womennovator.co.in/we-exhibition/"><span>WE Exhibition</span></a></li>
<li id="menu-item-4801" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4801"><a href="https://www.womennovator.co.in/womenmark-2/"><span>WE &#8211; Womenmark</span></a></li>
<li id="menu-item-4802" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4802"><a href="https://www.womennovator.co.in/brand-equity/"><span>WE &#8211; Brand Ambassador</span></a></li>
<li id="menu-item-4803" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4803"><a href="https://www.womennovator.co.in/management-planner/"><span>WE &#8211; Management Planner</span></a></li>
<li id="menu-item-286" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-286"><a href="https://www.womennovator.co.in/w-cell/"><span>WE-Cell</span></a></li>
<li id="menu-item-4804" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4804"><a href="https://www.womennovator.co.in/we-fund/"><span>WE &#8211; Fund</span></a></li>
<li id="menu-item-274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-274"><a href="https://www.womennovator.co.in/w-talks/"><span>WE-Talks</span></a></li>
<li id="menu-item-5340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5340"><a href="https://www.womennovator.co.in/mentors/"><span>WE Mentors</span></a></li>
<li id="menu-item-277" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-277"><a href="https://www.womennovator.co.in/w-vendor-meet/"><span>WE-Vendor Meet</span></a></li>
<li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="https://www.womennovator.co.in/w-embassy-meet/"><span>WE-Embassy Meet</span></a></li>
<li id="menu-item-291" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-291"><a href="https://www.womennovator.co.in/w-pitch-to-fund/"><span>WE-Pitch To Fund</span></a></li>
<li id="menu-item-1524" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1524"><a href="https://www.womennovator.co.in/w-global-tours/"><span>WE–Global Tours</span></a></li>
</ul>
</li>
<li id="menu-item-684" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-684"><a><span>KEYSTAKEHOLDERS</span></a>
<ul class="sub-menu">
<li id="menu-item-680" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-680"><a href="https://www.womennovator.co.in/apply-for-influencer/"><span>Influencer</span></a>
<ul class="sub-menu">
<li id="menu-item-466" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-466"><a href="https://www.womennovator.co.in/influencer-2021/"><span>INFLUENCER 2021</span></a></li>
<li id="menu-item-464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-464"><a target="_blank" rel="noopener noreferrer" href="https://www.womennovator.co.in/influencer-2018/"><span>INFLUENCER 2018</span></a></li>
</ul>
</li>
<li id="menu-item-230" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-230"><a href="https://www.womennovator.co.in/knowing-you-better-jurywi2019/"><span>Jury Members</span></a>
<ul class="sub-menu">
<li id="menu-item-2106" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2106"><a href="https://www.womennovator.co.in/jury-members-2019/"><span>JURY MEMBERS 2021</span></a></li>
<li id="menu-item-328" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-328"><a href="https://www.womennovator.co.in/jury-members-2018/"><span>JURY MEMBERS 2018</span></a></li>
</ul>
</li>
<li id="menu-item-4753" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4753"><a><span>women faces</span></a>
<ul class="sub-menu">
<li id="menu-item-4754" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4754"><a href="https://www.womennovator.co.in/winners/"><span>Women faces 2021</span></a></li>
<li id="menu-item-2094" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2094"><a href="https://www.womennovator.co.in/100-women-faces-2018/"><span>Women faces 2018</span></a></li>
</ul>
</li>
<li id="menu-item-5506" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5506"><a href="https://www.womennovator.co.in/join-our-community/"><span>Community Head</span></a></li>
<li id="menu-item-236" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-236"><a href="https://www.womennovator.co.in/value-partner/"><span>Value Partner</span></a></li>
<li id="menu-item-239" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-239"><a href="https://www.womennovator.co.in/academic-partner/"><span>Academic Partner</span></a></li>
<li id="menu-item-242" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-242"><a href="https://www.womennovator.co.in/association-partner/"><span>Association Partner</span></a></li>
<li id="menu-item-2242" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2242"><a href="https://womennovator.co.in/"><span>Committee</span></a>
<ul class="sub-menu">
<li id="menu-item-2243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2243"><a href="https://www.womennovator.co.in/management-committee-2/"><span>Management Committee</span></a></li>
<li id="menu-item-2244" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2244"><a href="https://www.womennovator.co.in/executive-committee/"><span>Executive Committee</span></a></li>
<li id="menu-item-2246" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2246"><a href="https://www.womennovator.co.in/mentor-2018/"><span>MENTORS</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="menu-item-415" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-415"><a><span>EVENTS</span></a>
<ul class="sub-menu">
<li id="menu-item-686" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-686"><a href="https://www.womennovator.co.in/upcoming-events/"><span>Upcoming Events</span></a></li>
<li id="menu-item-2093" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2093"><a href="https://www.womennovator.co.in/past-events/"><span>Past Events</span></a></li>
<li id="menu-item-4428" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4428"><a href="https://www.womennovator.co.in/speaker/"><span>SPEAKER</span></a></li>
</ul>
</li>
<li id="menu-item-416" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-416"><a><span>CATEGORY</span></a>
<ul class="sub-menu">
<li id="menu-item-851" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-851"><a href="https://www.womennovator.co.in/sectors/"><span>Sectors</span></a></li>
<li id="menu-item-2304" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2304"><a href="https://www.womennovator.co.in/india/"><span>City</span></a></li>
</ul>
</li>
<li id="menu-item-2722" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2722"><a><span>WORK WITH US</span></a>
<ul class="sub-menu">
<li id="menu-item-2608" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2608"><a href="https://www.womennovator.co.in/internship/"><span>INTERNSHIP</span></a></li>
<li id="menu-item-2721" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2721"><a target="_blank" rel="noopener noreferrer" href="https://www.womennovator.co.in/career-2/"><span>CAREER</span></a></li>
</ul>
</li>
<li id="menu-item-5522" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5522"><a href="http://covidcaregiver.org/"><span>CovidCare</span></a></li>
</ul></nav><a class="responsive-menu-toggle  is-sticky" href="#"><i class="icon-menu-fine"></i></a>					
    </div>			
    
    <div class="secondary_menu_wrapper">
        <!-- #secondary-menu -->
                        </div>
    
    <div class="banner_wrapper">
                        </div>
    
    <div class="search_wrapper">
        <!-- #searchform -->
        
        
<form method="get" id="searchform" action="https://www.womennovator.co.in/">
            

<i class="icon_search icon-search-fine"></i>
<a href="#" class="icon_close"><i class="icon-cancel-fine"></i></a>

<input type="text" class="field" name="s" placeholder="Enter your search" />			
<input type="submit" class="submit" value="" style="display:none;" />

</form>					
    </div>				
    
</div>

<div class="top_bar_right"><div class="top_bar_right_wrapper"><a href="{{ url('apply-for/')}}" class="action_button" target="_blank">APPLY NOW</a></div></div>			
</div>
</div>
</div>				<div class="mfn-main-slider" id="mfn-rev-slider">
<div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;">
<!-- START REVOLUTION SLIDER 5.4.8 auto mode -->
<div id="rev_slider_1_1" class="rev_slider fullwidthabanner tp-overflow-hidden" style="display:none;" data-version="5.4.8">
<ul>	<!-- SLIDE  -->
<li data-index="rs-75" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.youtube.com/watch?v=o5Y0p1TKkWk"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2021/01/cover-image-100x50.png"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2021/01/cover-image.png"  alt="" title="cover image"  width="851" height="428" data-bgposition="center center" data-bgfit="cover" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->

<!-- BACKGROUND VIDEO LAYER -->
<div class="rs-background-video-layer" 
data-forcerewind="on" 
data-volume="mute" 
data-ytid="o5Y0p1TKkWk" 
data-videoattributes="version=3&amp;enablejsapi=1&amp;html5=1&amp;hd=1&wmode=opaque&showinfo=0&rel=0;;origin=https://www.womennovator.co.in;" 
data-videorate="1" 
data-videowidth="100%" 
data-videoheight="100%" 
data-videocontrols="none" 
data-videoloop="none" 
data-forceCover="1" 
data-aspectratio="16:9" 
data-autoplay="true" 
data-autoplayonlyfirsttime="false" 
></div>	</li>
<!-- SLIDE  -->
<li data-index="rs-83" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-01-at-12.58.27-1-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/09/WhatsApp-Image-2020-09-01-at-12.58.27-1.jpeg"  alt="" title="WhatsApp Image 2020-09-01 at 12.58.27 (1)"  width="1280" height="361" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-68" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.27-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.27.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.27"  width="1280" height="782" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-76" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.27-1-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.27-1.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.27 (1)"  width="960" height="480" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-77" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.12-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.12.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.12"  width="1075" height="720" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-78" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.11-1-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.11-1.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.11 (1)"  width="1075" height="720" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-79" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.11-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.11.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.11"  width="1075" height="720" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-80" data-transition="notransition" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-link="https://www.womennovator.co.in/women-application-2019/"  data-target="_blank"  data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.10-100x50.jpeg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-09-at-01.21.10.jpeg"  alt="" title="WhatsApp Image 2020-10-09 at 01.21.10"  width="1075" height="720" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-18" data-transition="notransition,fade" data-slotamount="default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default,default" data-easeout="default,default" data-masterspeed="300,default"  data-link="https://www.womennovator.co.in/women-application-2019/"   data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/04/1-100x50.png"  data-rotate="0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/04/1.png"  alt="" title="1"  width="1720" height="600" data-bgposition="center center" data-bgfit="100% 100%" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-19" data-transition="notransition,slidehorizontal,fadetorightfadefromleft" data-slotamount="default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default,default,default" data-easeout="default,default,default" data-masterspeed="default,default,default"  data-link="https://www.womennovator.co.in/women-application-2019/"   data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/04/2-100x50.png"  data-rotate="0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/04/2.png"  alt="" title="2"  width="1720" height="600" data-bgposition="center center" data-bgfit="100% 100%" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-23" data-transition="notransition,slidehorizontal,fadetorightfadefromleft" data-slotamount="default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default,default,default" data-easeout="default,default,default" data-masterspeed="default,default,default"  data-link="https://www.womennovator.co.in/women-application-2019/"   data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/04/3-100x50.png"  data-rotate="0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/04/3.png"  alt="" title="3"  width="1720" height="600" data-bgposition="center center" data-bgfit="100% 100%" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-24" data-transition="notransition,slidehorizontal,fadetorightfadefromleft" data-slotamount="default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default,default,default" data-easeout="default,default,default" data-masterspeed="default,default,default"  data-link="https://www.womennovator.co.in/women-application-2019/"   data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/04/4-100x50.png"  data-rotate="0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/04/4.png"  alt="" title="4"  width="1720" height="600" data-bgposition="center center" data-bgfit="100% 100%" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
<!-- SLIDE  -->
<li data-index="rs-25" data-transition="notransition,slidehorizontal,fadetorightfadefromleft" data-slotamount="default,default,default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default,default,default" data-easeout="default,default,default" data-masterspeed="default,default,default"  data-link="https://www.womennovator.co.in/women-application-2019/"   data-thumb="https://www.womennovator.co.in/wp-content/uploads/2020/04/5-100x50.png"  data-rotate="0,0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="https://www.womennovator.co.in/wp-content/uploads/2020/04/5.png"  alt="" title="5"  width="1720" height="600" data-bgposition="center center" data-bgfit="100% 100%" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
</li>
</ul>
<div class="tp-bannertimer" style="height: 3px; background: rgba(255,58,45,1);"></div>	</div>
<script>
        var htmlDivCss = '	#rev_slider_1_1_wrapper .tp-loader.spinner4 div { background-color: #5d0443 !important; } ';
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if(htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        }
        else{
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        }
        </script>
        </div><!-- END REVOLUTION SLIDER --></div>			</header>


</div>