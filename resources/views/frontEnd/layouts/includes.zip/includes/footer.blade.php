<!-- mfn_hook_content_after --><!-- mfn_hook_content_after -->
	<!-- #Footer -->
	<footer id="Footer" class="clearfix">

		
		<div class="widgets_wrapper" style="padding:80px 0 80px;"><div class="container"><div class="column one-fifth"><aside id="custom_html-2" class="widget_text widget widget_custom_html"><h4>About us</h4><div class="textwidget custom-html-widget"><p style="text-align: justify; line-height: 32px; font-size: 15px;">
	Womennovator – First Virtual Incubator for Women #NaariShakti...<a href="http://capit-all.in/about/"><span style="color: white;">read more</span>
	</a>
</p>
<a href="https://www.facebook.com/womennovator/" class="icon_bar  icon_bar_facebook icon_bar_small" target="_blank" rel="noopener noreferrer"><span class="t"><i class="icon-facebook"></i></span><span class="b"><i class="icon-facebook"></i></span></a>

<a href="https://www.instagram.com/womennovator" class="icon_bar  icon_bar_vimeo icon_bar_small" target="_blank" rel="noopener noreferrer"><span class="t"><i class="icon-instagram"></i></span><span class="b"><i class="icon-instagram"></i></span></a>

<a href="https://twitter.com/womennovator" class="icon_bar  icon_bar_twitter icon_bar_small" target="_blank" rel="noopener noreferrer"><span class="t"><i class="icon-twitter"></i></span><span class="b"><i class="icon-twitter"></i></span></a>

<a href="https://www.linkedin.com/company/womenovator/" class="icon_bar  icon_bar_linkedin icon_bar_small" target="_blank" rel="noopener noreferrer"><span class="t"><i class="icon-linkedin"></i></span><span class="b"><i class="icon-linkedin"></i></span></a>

<a href="https://www.youtube.com/channel/UCY7ojnIQ727UzC6cSnO7PIA" class="icon_bar  icon_bar_youtube icon_bar_small" target="_blank" rel="noopener noreferrer"><span class="t"><i class="icon-play"></i></span><span class="b"><i class="icon-play"></i></span></a>

</div></aside></div><div class="column one-fifth"><aside id="custom_html-3" class="widget_text widget widget_custom_html"><h4>Programs we offer</h4><div class="textwidget custom-html-widget"><ul style="line-height: 32px;font-size: 15px;">
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/w-talks/">WE-Talks</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/w-vendor-meet/">WE-Vendor Meet</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/#">WE-Embassy Meet
</a></li>
	<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/w-cell/">WE-Cell</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/w-pitch-to-fund/">WE-Pitch to Fund</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/w-global-tours/">WE-Global Tours</a></li>
</ul></div></aside></div><div class="column one-fifth"><aside id="custom_html-4" class="widget_text widget widget_custom_html"><h4>Important Links</h4><div class="textwidget custom-html-widget"><ul style="line-height: 32px; font-size: 15px;">
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/sectors/">Sectors</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/india/">Cities</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/upcoming-events/">Upcoming Events</a></li>
	<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="#">Terms & Condition</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/contact-2/">Contact</a></li>
<li><i class="icon-right-dir" style="color: #d1d2d2;"></i> <a href="https://www.womennovator.co.in/faq">FAQ</a></li>
</ul></div></aside></div><div class="column one-fifth"><aside id="custom_html-7" class="widget_text widget widget_custom_html"><h4>Call us at</h4><div class="textwidget custom-html-widget"><ul style="line-height: 32px; align: justify; font-size: 15px;">
<li>
<i class="icon-mobile - phone" style="color: #d1d2d2;"></i> (+91)-9315854688</li>
<li>
	<a href="https://www.google.com/maps/dir//kgs+advisors/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x390cfd2718af1fa1:0xd6c65ab823f35951?sa=X&ved=2ahUKEwjIge2BlqXlAhXgIbcAHaH-D6IQ9RcwDHoECAkQDA" target="_blank" rel="noopener noreferrer">
<li style="color: white;"><i class="icon-location" style="color: #d1d2d2; letter-spacing: 1px;"></i> We are on  google</li>
		</a>
	</li>
</ul>
</div></aside></div><div class="column one-fifth"><aside id="custom_html-6" class="widget_text widget widget_custom_html"><h4>Get Involved</h4><div class="textwidget custom-html-widget"><a href="https://www.womennovator.co.in/host-partner/">
<button style="background: none;
    border: 2px solid #f5f5dc;
    border-radius: 1px;
    width: 230px;
    font-size: 15px;">
		Apply for
 Host	</button>
	</a>

<a href="{{ url('http://www.womennovators.com/faces/login')}}">
	<button style="background: none;
    border: 2px solid #f5f5dc;
    border-radius: 1px;
    width: 230px;
    font-size: 15px;">
		Apply for
 Women Faces	</button>
</a>

<a href="{{ url('http://www.womennovators.com/influencer/login')}}">
	<button style="background: none;
    border: 2px solid #f5f5dc;
    border-radius: 1px;
    width: 230px;
    font-size: 15px;">
		Apply for
 Influencer	</button>
	</a>

<a href="{{('http://www.womennovators.com/login')}}">
	<button style="background: none;
    border: 2px solid #f5f5dc;
    border-radius: 1px;
    width: 230px;
    font-size: 15px;">
		Apply for
 Jury	</button>
	</a></div></aside></div></div></div>
		
			<div class="footer_copy">
				<div class="container">
					<div class="column one">

						
						<!-- Copyrights -->
						<div class="copyright">
							© 2020 Womennnovator. All Rights Reserved.						</div>

						<nav id="social-menu" class="menu-bottom-menu-container"><ul id="menu-bottom-menu" class="social-menu"><li id="menu-item-1054" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1054"><a href="https://www.womennovator.co.in/about/">About</a></li>
<li id="menu-item-1057" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1057"><a href="https://www.womennovator.co.in/gallery/">Gallery</a></li>
<li id="menu-item-1053" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1053"><a href="https://www.womennovator.co.in/upcoming-events/">Upcoming Events</a></li>
<li id="menu-item-4576" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4576"><a href="https://www.womennovator.co.in/wp-content/uploads/2020/08/Learning-in-Lockdown_26th-June-2020_Report.pdf">Knowledge center</a></li>
<li id="menu-item-3077" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3077"><a href="https://www.womennovator.co.in/news/">News</a></li>
<li id="menu-item-2775" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2775"><a href="https://www.womennovator.co.in/media-2/">Media</a></li>
<li id="menu-item-2735" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2735"><a href="https://www.womennovator.co.in/contact-2/">Contact</a></li>
<li id="menu-item-5393" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5393"><a href="https://www.womennovator.co.in/faq/">FAQ</a></li>
</ul></nav>
					</div>
				</div>
			</div>

		
		
	</footer>