<!--Start of Tawk.to Script (0.3.3)-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{};
var Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5dde251d43be710e1d1f4f62/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script (0.3.3)-->			<script type="text/javascript">
				function revslider_showDoubleJqueryError(sliderID) {
					var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
					errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
					errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
					errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
					errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
						jQuery(sliderID).show().html(errorMessage);
				}
			</script>
			<link rel='stylesheet' id='ivory-search-styles-css'  href='https://www.womennovator.co.in/wp-content/plugins/add-search-to-menu/public/css/ivory-search.css?ver=4.4.6' type='text/css' media='all' />
<link rel='stylesheet' id='cf-front-css'  href='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/assets/build/css/caldera-forms-front.min.css?ver=1.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='cf-render-css'  href='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/clients/render/build/style.min.css?ver=1.8.10' type='text/css' media='all' />
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/add-search-to-menu/public/js/ivory-search.js?ver=4.4.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.womennovator.co.in\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.6'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/gs-logo-slider/gsl-files/js/jquery.bxslider.min.js?ver=1.8.6'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/gs-logo-slider/gsl-files/js/jquery.easing.1.3.js?ver=1.8.6'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/gs-logo-slider/gsl-files/js/gs-logo-custom.js?ver=1.8.6'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.actions.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.carousel.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.kenburn.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.layeranimation.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.migration.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.navigation.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.parallax.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.slideanims.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/extensions/revolution.extension.video.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/sortable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/js/plugins.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/js/menu.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/assets/animations/animations.min.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/assets/jplayer/jplayer.min.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/js/parallax/translate3d.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/js/parallax/smoothscroll.js?ver=20.9.5.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/themes/betheme/js/scripts.js?ver=20.9.5.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7cf_global_settings = {"ajaxurl":"https:\/\/www.womennovator.co.in\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/cf7-conditional-fields/js/scripts.js?ver=1.8.3'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/wp-embed.min.js?ver=5.4.6'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/assets/build/js/jquery-baldrick.min.js?ver=1.8.10'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/assets/build/js/parsley.min.js?ver=1.8.10'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4'></script>
<script type='text/javascript'>
( 'fetch' in window ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="https://www.womennovator.co.in/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr' + 'ipt>' );
</script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/dist/vendor/react.min.js?ver=16.9.0'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/dist/vendor/react-dom.min.js?ver=16.9.0'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-includes/js/dist/dom-ready.min.js?ver=91fc8f05178d5c6365aec778f840ae17'></script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/clients/render/build/index.min.js?ver=1.8.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var CF_API_DATA = {"rest":{"root":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v2\/","rootV3":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v3\/","fileUpload":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v3\/file","tokens":{"nonce":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v2\/tokens\/form"},"nonce":"8fa049ef46"},"strings":{"cf2FileField":{"removeFile":"Remove file","defaultButtonText":"Drop files or click to select files to Upload","fileUploadError1":"Error: ","fileUploadError2":" could not be processed","invalidFiles":"These Files have been rejected : ","checkMessage":"Please check files type and size","invalidFileResponse":"Unknown File Process Error","fieldIsRequired":"Field is required","filesUnit":"bytes","maxSizeAlert":"This file is too large. Maximum size is ","wrongTypeAlert":"This file type is not allowed. Allowed types are "}},"nonce":{"field":"_cf_verify"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.womennovator.co.in/wp-content/plugins/caldera-forms/assets/build/js/caldera-forms-front.min.js?ver=1.8.10'></script>
<script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss="";
				if(htmlDiv) {
					htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
				}else{
					var htmlDiv = document.createElement("div");
					htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
					document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
				}
			</script>
		<script type="text/javascript">
if (setREVStartSize!==undefined) setREVStartSize(
	{c: '#rev_slider_1_1', responsiveLevels: [1240,1024,1024,1024], gridwidth: [1720,1024,1024,1024], gridheight: [700,500,500,500], sliderLayout: 'auto'});
			
var revapi1,
	tpj;	
(function() {			
	if (!/loaded|interactive|complete/.test(document.readyState)) document.addEventListener("DOMContentLoaded",onLoad); else onLoad();	
	function onLoad() {				
		if (tpj===undefined) { tpj = jQuery; if("off" == "on") tpj.noConflict();}
	if(tpj("#rev_slider_1_1").revolution == undefined){
		revslider_showDoubleJqueryError("#rev_slider_1_1");
	}else{
		revapi1 = tpj("#rev_slider_1_1").show().revolution({
			sliderType:"standard",
			jsFileLocation:"//www.womennovator.co.in/wp-content/plugins/revslider/public/assets/js/",
			sliderLayout:"auto",
			dottedOverlay:"none",
			delay:3000,
			navigation: {
				onHoverStop:"off",
			},
			responsiveLevels:[1240,1024,1024,1024],
			visibilityLevels:[1240,1024,1024,1024],
			gridwidth:[1720,1024,1024,1024],
			gridheight:[700,500,500,500],
			lazyType:"none",
			shadow:0,
			spinner:"spinner4",
			stopLoop:"off",
			stopAfterLoops:-1,
			stopAtSlide:-1,
			shuffle:"off",
			autoHeight:"off",
			hideThumbsOnMobile:"off",
			hideSliderAtLimit:0,
			hideCaptionAtLimit:0,
			hideAllCaptionAtLilmit:0,
			debugMode:false,
			fallbacks: {
				simplifyAll:"off",
				nextSlideOnWindowFocus:"off",
				disableFocusListener:false,
			}
		});
	}; /* END OF revapi call */
	
 }; /* END OF ON LOAD FUNCTION */
}()); /* END OF WRAPPING FUNCTION */
</script>
		<!-- script | custom js -->
<script id="mfn-dnmc-custom-js">
//<![CDATA[
// Get the modal
var modal = document.getElementById('myModal');
var modall = document.getElementById('myModall');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");
var btnn = document.getElementById("myBtnn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

btnn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
//span.onclick = function() {
   // modal.style.display = "none";
// }

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

//]]>
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var CF_API_DATA = {"rest":{"root":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v2\/","rootV3":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v3\/","fileUpload":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v3\/file","tokens":{"nonce":"https:\/\/www.womennovator.co.in\/wp-json\/cf-api\/v2\/tokens\/form"},"nonce":"8fa049ef46"},"strings":{"cf2FileField":{"removeFile":"Remove file","defaultButtonText":"Drop files or click to select files to Upload","fileUploadError1":"Error: ","fileUploadError2":" could not be processed","invalidFiles":"These Files have been rejected : ","checkMessage":"Please check files type and size","invalidFileResponse":"Unknown File Process Error","fieldIsRequired":"Field is required","filesUnit":"bytes","maxSizeAlert":"This file is too large. Maximum size is ","wrongTypeAlert":"This file type is not allowed. Allowed types are "}},"nonce":{"field":"_cf_verify"}};
var CFFIELD_CONFIG = {"1":{"configs":{"fld_1926623":{"type":"button","id":"fld_1926623_1","default":"","form_id":"CF5d5cfe23d5e57","form_id_attr":"caldera_form_1"}},"fields":{"ids":["fld_743861_1","fld_9692982_1","fld_707520_1","fld_1926623_1"],"inputs":[{"type":"text","fieldId":"fld_743861","id":"fld_743861_1","options":[],"default":""},{"type":"text","fieldId":"fld_9692982","id":"fld_9692982_1","options":[],"default":""},{"type":"email","fieldId":"fld_707520","id":"fld_707520_1","options":[],"default":""},{"type":"button","fieldId":"fld_1926623","id":"fld_1926623_1","options":[],"default":""}],"groups":[],"defaults":{"fld_743861_1":"","fld_9692982_1":"","fld_707520_1":"","fld_1926623_1":""},"calcDefaults":{"fld_743861_1":0,"fld_9692982_1":0,"fld_707520_1":0,"fld_1926623_1":0}},"error_strings":{"mixed_protocol":"Submission URL and current URL protocols do not match. Form may not function properly."}}};
/* ]]> */
</script>
<script>	
	window.addEventListener("load", function(){

		jQuery(document).on('click dblclick', '#fld_1926623_1', function( e ){
			jQuery('#fld_1926623_1_btn').val( e.type ).trigger('change');
		});

	});
</script>
<script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
</script>