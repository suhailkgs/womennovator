Dear Sir/Madam,
<br/><br/>
<h3>We Recieve your Request</h3>
<br/>
<a href="{{url('/certificates/'.$id )}}">View Certificate</a>
<p>For any queries you can contact:
Mr. Hari Om : +91 95607 03449

<br/>For more information, check out our social media handles:
<br/><a href="https://www.facebook.com/womennovator">Facebook: https://www.facebook.com/womennovator</a>
<br/><a href="https://www.linkedin.com/company/womenovator/">Linkedin: https://www.linkedin.com/company/womenovator/</a>
<br/><a href="https://twitter.com/womennovator">Twitter: https://twitter.com/womennovator</a>
<br/><a href="https://www.youtube.com/c/WomennovatorOfficial">Youtube: https://www.youtube.com/c/WomennovatorOfficial</a>
<br/><a href=" https://www.instagram.com/womennovator">Instagram: https://www.instagram.com/womennovator</a>
</p>
<h4>Warm Regards,<br/>Team Womennovator</h4>