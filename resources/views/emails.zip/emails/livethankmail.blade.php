Dear {{$name ??'' }},
<br/><br/>
<h3>Thank You so much for showing Interest in Our Live Series!</h3>

<h4>Regards<br/>Team Womennovator</h4>