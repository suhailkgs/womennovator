Dear Sir/Madam
<br><br>
<p>Your OTP for We-Pitch Jury Verification is :<b> {{ $otp ??'' }}</b></p>
<br>
<h4>Regards<br/>Team Womennovator</h4>